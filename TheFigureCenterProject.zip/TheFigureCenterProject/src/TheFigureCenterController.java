import javafx.fxml.FXML;
import java.awt.event.ActionEvent;

import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;

public class TheFigureCenterController {

    @FXML
    private Pane fullPane;

    @FXML
    private Pane radioButtonPane;

    @FXML
    private RadioButton rectangleRadioButton;

    @FXML
    private ToggleGroup radioButtons;

    @FXML
    private RadioButton boxRadioButton;

    @FXML
    private RadioButton circleRadioButton;

    @FXML
    private RadioButton cylinderRadioButton;

    @FXML
    private Pane widthPane;

    @FXML
    private TextField widthTextField;

    @FXML
    private Pane lengthPane;

    @FXML
    private TextField lengthTextField;

    @FXML
    private Pane radiusPane;

    @FXML
    private TextField radiusTextField;

    @FXML
    private Pane heightPane;

    @FXML
    private TextField heightTextField;

    @FXML
    private Button processButton;

    @FXML
    void boxRadioButtonClicked(ActionEvent event) {

    }

    @FXML
    void circleRadioButtonClicked(ActionEvent event) {

    }

    @FXML
    void cylinderRadioButtonClicked(ActionEvent event) {

    }

    @FXML
    void processButtonClicked(ActionEvent event) {

    }

    @FXML
    void rectangleRadioButtonClicked(ActionEvent event) {

    }
    
    public void initialize() {
       radiusPane.setVisible(false);
     }

}
